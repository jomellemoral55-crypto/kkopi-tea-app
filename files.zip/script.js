/* KKOPI.Tea – Phase 1 */
const page = document.body.dataset.page;
const $ = (s) => document.querySelector(s);

/* ---------- Auth service (swap these bodies for Firebase later) ----------
   import { initializeApp } from "firebase/app";
   import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword,
            sendPasswordResetEmail, updateProfile } from "firebase/auth";
   const app = initializeApp({ apiKey:"...", authDomain:"...", projectId:"..." });
   const auth = getAuth(app);
*/
const authService = {
  async login(email, password)  { /* return signInWithEmailAndPassword(auth, email, password); */ return { email }; },
  async register(data)          { /* const c = await createUserWithEmailAndPassword(auth, data.email, data.password);
                                     await updateProfile(c.user, { displayName: data.name }); return c; */ return data; },
  async resetPassword(email)    { /* return sendPasswordResetEmail(auth, email); */ return { email }; }
};

/* ---------- Validation ---------- */
const rules = {
  name:     (v) => v.trim().length >= 2 || "Enter your full name.",
  email:    (v) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) || "Enter a valid email address.",
  phone:    (v) => /^(\+63|0)?9\d{9}$/.test(v.replace(/[\s-]/g, "")) || "Enter a valid PH mobile number (e.g. 09171234567).",
  password: (v) => v.length >= 6 || "Password must be at least 6 characters.",
  confirm:  (v) => v === $("#password")?.value || "Passwords do not match."
};
function validate(form) {
  let ok = true;
  form.querySelectorAll("[data-rule]").forEach((input) => {
    const res = rules[input.dataset.rule](input.value);
    const field = input.closest(".field");
    field.classList.toggle("invalid", res !== true);
    field.querySelector(".error").textContent = res === true ? "" : res;
    if (res !== true) ok = false;
  });
  return ok;
}
function bindForm(id, onValid) {
  const form = $(id);
  if (!form) return;
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (!validate(form)) return;
    const btn = form.querySelector("button[type=submit]");
    btn.disabled = true;
    try { await onValid(Object.fromEntries(new FormData(form))); }
    catch (err) { alert(err.message || "Something went wrong. Try again."); btn.disabled = false; }
  });
  form.querySelectorAll("[data-rule]").forEach((i) => i.addEventListener("input", () => i.closest(".field").classList.remove("invalid")));
}

/* ---------- Pages ---------- */
if (page === "splash") setTimeout(() => (location.href = "login.html"), 3000);

if (page === "login") {
  const saved = localStorage.getItem("kkopi_email");
  if (saved) { $("#email").value = saved; $("#remember").checked = true; }
  bindForm("#loginForm", async (d) => {
    await authService.login(d.email, d.password);
    $("#remember").checked ? localStorage.setItem("kkopi_email", d.email) : localStorage.removeItem("kkopi_email");
    location.href = "home.html";
  });
}
if (page === "register") bindForm("#registerForm", async (d) => { await authService.register(d); location.href = "home.html"; });

if (page === "forgot") bindForm("#forgotForm", async (d) => {
  await authService.resetPassword(d.email);
  $("#msg").classList.add("show");
  setTimeout(() => (location.href = "login.html"), 2500);
});

if (page === "home") {
  $("#startOrdering").addEventListener("click", () => (location.href = "menu.html")); // Phase 2 page
  document.querySelectorAll(".chip").forEach((c) => c.addEventListener("click", () => {
    document.querySelectorAll(".chip").forEach((x) => x.classList.remove("active")); c.classList.add("active");
  }));
  $("#searchInput").addEventListener("keydown", (e) => {
    if (e.key === "Enter" && e.target.value.trim()) location.href = "menu.html?search=" + encodeURIComponent(e.target.value.trim());
  });
}
